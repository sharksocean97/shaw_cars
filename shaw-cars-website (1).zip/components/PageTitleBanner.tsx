
import React from 'react';

interface PageTitleBannerProps {
  title: string;
}

const PageTitleBanner: React.FC<PageTitleBannerProps> = ({ title }) => {
  return (
    <header className="bg-white text-black py-6 md:py-8 shadow-md">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl md:text-6xl font-bold tracking-wider text-center uppercase">
          {title}
        </h1>
      </div>
    </header>
  );
};

export default PageTitleBanner;
