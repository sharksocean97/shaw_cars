
import React from 'react';
import type { NavLink } from '../types';

interface NavigationProps {
  navLinks: NavLink[];
}

const Navigation: React.FC<NavigationProps> = ({ navLinks }) => {
  return (
    <nav className="bg-gray-900 sticky top-0 z-50 shadow-lg">
      <div className="container mx-auto px-4">
        <ul className="flex flex-wrap justify-center items-center py-3 md:py-4 space-x-4 md:space-x-6">
          {navLinks.map((link) => (
            <li key={link.name}>
              <a
                href={link.href}
                className="text-gray-300 hover:text-white hover:bg-gray-700 px-3 py-2 rounded-md text-sm md:text-base font-medium transition-colors duration-150"
              >
                {link.name}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
};

export default Navigation;
