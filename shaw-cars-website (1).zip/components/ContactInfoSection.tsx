
import React from 'react';
import type { ContactDetails } from '../types';

interface ContactInfoSectionProps {
  id: string;
  details: ContactDetails;
}

const DetailItem: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="mb-6 md:mb-8">
    <h3 className="text-2xl md:text-3xl font-semibold text-white mb-2 md:mb-3">{title}</h3>
    <div className="text-md md:text-lg text-gray-300 leading-relaxed">{children}</div>
  </div>
);

const ContactInfoSection: React.FC<ContactInfoSectionProps> = ({ id, details }) => {
  return (
    <section id={id} className="py-12 md:py-20 border-t border-gray-800">
      <div className="container mx-auto px-4 text-center md:text-left">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-10 md:mb-16 uppercase tracking-wide">
          Contact Us
        </h2>
        <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-1 gap-8">
          <DetailItem title="Phone">
            <a href={`tel:${details.phone.replace(/\s/g, '')}`} className="hover:text-blue-400 transition-colors">
              {details.phone}
            </a>
          </DetailItem>
          
          <DetailItem title="E-mail">
            <a href={`mailto:${details.email}`} className="hover:text-blue-400 transition-colors">
              {details.email}
            </a>
          </DetailItem>
          
          <DetailItem title="Address">
            {details.address.map((line, index) => (
              <p key={index}>{line}</p>
            ))}
          </DetailItem>
        </div>
        {/* Company Reg and VAT moved to footer in App.tsx for global visibility, but could be here too */}
      </div>
    </section>
  );
};

export default ContactInfoSection;
