
import React from 'react';

interface IntroTextSectionProps {
  id: string;
  textLines: string[];
}

const IntroTextSection: React.FC<IntroTextSectionProps> = ({ id, textLines }) => {
  return (
    <section id={id} className="py-12 md:py-20 text-center">
      <div className="max-w-3xl mx-auto">
        {textLines.map((line, index) => (
          <p key={index} className="text-lg md:text-xl text-gray-300 mb-4 leading-relaxed">
            {line}
          </p>
        ))}
      </div>
    </section>
  );
};

export default IntroTextSection;
