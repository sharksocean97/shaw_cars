
import React from 'react';

interface ServiceSectionProps {
  id: string;
  title: string;
  imageUrl: string;
  imageAlt: string;
  textLines: string[];
}

const ServiceSection: React.FC<ServiceSectionProps> = ({ id, title, imageUrl, imageAlt, textLines }) => {
  return (
    <section id={id} className="py-12 md:py-20 border-t border-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-8 md:mb-12 uppercase tracking-wide">
          {title}
        </h2>
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
          <div className="md:w-1/2">
            <img 
              src={imageUrl} 
              alt={imageAlt} 
              className="rounded-lg shadow-2xl w-full h-auto object-cover aspect-video" 
            />
          </div>
          <div className="md:w-1/2 text-left">
            {textLines.map((line, index) => (
              <p key={index} className="text-md md:text-lg text-gray-300 mb-4 leading-relaxed">
                {line}
              </p>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServiceSection;
